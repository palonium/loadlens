import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import path from 'path';
import { fileURLToPath } from 'url';
import authRoutes from "./src/routes/authRoutes.js";
import scenarRoutes from "./src/routes/scenarRoutes.js";
import userRoutes from "./src/routes/userRoutes.js";
import testUserRoutes from "./src/routes/testUserRoutes.js";
import abRoutes from "./src/routes/abRoutes.js";
import uploadRoutes from "./src/routes/uploadRoutes.js"; 
import reportRoutes from "./src/routes/reportRoutes.js";

const app = express();
const port = 3000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors({
  origin: "http://localhost:5173",
  credentials: true
}));

app.use(cookieParser());
app.use(express.json({ limit: "20mb" }));

// 🔹 Статическая раздача изображений
app.use("/uploads", express.static(path.join(__dirname, "public/uploads")));

// 🔹 API маршруты
app.use("/api/auth", authRoutes);
app.use("/api/scenarios", scenarRoutes);
app.use("/api/users", userRoutes);
app.use("/api/test_users", testUserRoutes);
app.use("/api", abRoutes);
app.use("/api", uploadRoutes); // ✅ добавлено
app.use("/api/reports", reportRoutes);

app.listen(port, () => {
  console.log("✅ Server running on port 3000");
});
